document.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");
  if (!token) {
    window.location.href = "/login";
    return;
  }

  const profileForm = document.getElementById("profileForm");
  const passwordForm = document.getElementById("passwordForm");
  const logoutBtn = document.getElementById("logoutBtn");

  // Load profile data
  loadProfile();

  if (profileForm) {
    profileForm.addEventListener("submit", handleProfileUpdate);
  }

  if (passwordForm) {
    passwordForm.addEventListener("submit", handlePasswordChange);
  }

  if (logoutBtn) {
    logoutBtn.addEventListener("click", logout);
  }

  // Check if we're on public profile page
  const path = window.location.pathname;

  if (path === "/profile") {
    loadProfile();
  }

  if (path.startsWith("/user/")) {
    const userId = path.split("/").pop();
    loadPublicProfile(userId);
  }
});

async function loadProfile() {
  const usernameInput = document.getElementById("username");

  if (!usernameInput) return;

  try {
    const token = localStorage.getItem("token");
    const response = await axios.get("/api/users/profile", {
      headers: { Authorization: `Bearer ${token}` },
    });
    const user = response.data.user;

    document.getElementById("username").value = user.username || "";
    document.getElementById("email").value = user.email || "";
    document.getElementById("first_name").value = user.first_name || "";
    document.getElementById("last_name").value = user.last_name || "";
    document.getElementById("bio").value = user.bio || "No bio added.";
    document.getElementById("dietary_preferences").value = Array.isArray(
      user.dietary_preferences,
    )
      ? user.dietary_preferences.join(", ")
      : "";
    document.getElementById("profile_picture").value =
      user.profile_picture || "";
  } catch (error) {
    if (error.response?.status === 401) {
      logout();
    } else {
      alert(
        "Failed to load profile: " +
          (error.response?.data?.message || error.message),
      );
    }
  }
}

async function handleProfileUpdate(e) {
  e.preventDefault();
  const messageEl = document.getElementById("updateMessage");
  const errorEl = document.getElementById("updateError");
  const submitBtn = e.target.querySelector('button[type="submit"]');

  messageEl.classList.remove("show");
  errorEl.classList.remove("show");
  submitBtn.disabled = true;
  submitBtn.textContent = "Updating...";

  try {
    const token = localStorage.getItem("token");
    const dietaryPrefs = document
      .getElementById("dietary_preferences")
      .value.split(",")
      .map((item) => item.trim())
      .filter((item) => item);

    const response = await axios.put(
      "/api/users/profile",
      {
        first_name: document.getElementById("first_name").value,
        last_name: document.getElementById("last_name").value,
        bio: document.getElementById("bio").value,
        dietary_preferences: dietaryPrefs,
        profile_picture: document.getElementById("profile_picture").value,
      },
      {
        headers: { Authorization: `Bearer ${token}` },
      },
    );

    messageEl.textContent = response.data.message;
    messageEl.classList.add("show");
    submitBtn.disabled = false;
    submitBtn.textContent = "Update Profile";

    // Update stored user data
    localStorage.setItem("user", JSON.stringify(response.data.user));
  } catch (error) {
    errorEl.textContent = error.response?.data?.message || error.message;
    errorEl.classList.add("show");
    submitBtn.disabled = false;
    submitBtn.textContent = "Update Profile";
  }
}

async function handlePasswordChange(e) {
  e.preventDefault();
  const messageEl = document.getElementById("passwordMessage");
  const errorEl = document.getElementById("passwordError");
  const submitBtn = e.target.querySelector('button[type="submit"]');

  messageEl.classList.remove("show");
  errorEl.classList.remove("show");
  submitBtn.disabled = true;
  submitBtn.textContent = "Changing...";

  try {
    const token = localStorage.getItem("token");
    await axios.put(
      "/api/users/change-password",
      {
        current_password: document.getElementById("current_password").value,
        new_password: document.getElementById("new_password").value,
      },
      {
        headers: { Authorization: `Bearer ${token}` },
      },
    );

    messageEl.textContent = "Password changed successfully!";
    messageEl.classList.add("show");
    e.target.reset();
    submitBtn.disabled = false;
    submitBtn.textContent = "Change Password";
  } catch (error) {
    errorEl.textContent = error.response?.data?.message || error.message;
    errorEl.classList.add("show");
    submitBtn.disabled = false;
    submitBtn.textContent = "Change Password";
  }
}

// ============ PUBLIC PROFILE FUNCTIONS ============

async function toggleFollow(targetUserId, currentlyFollowing) {
  const btn = document.getElementById("follow-profile-btn");
  btn.disabled = true;
  btn.textContent = "Processing...";

  try {
    const token = localStorage.getItem("token");

    if (currentlyFollowing) {
      await axios.delete(`/api/follows/${targetUserId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      btn.textContent = "Follow";
      btn.classList.remove("following");
      showNotification("Unfollowed user successfully");
    } else {
      await axios.post(
        "/api/follows",
        { user_id: targetUserId },
        { headers: { Authorization: `Bearer ${token}` } },
      );
      btn.textContent = "Unfollow";
      btn.classList.add("following");
      showNotification("Following user successfully");
    }

    btn.disabled = false;
    loadFollowCounts(targetUserId);
  } catch (error) {
    btn.disabled = false;
    btn.textContent = currentlyFollowing ? "Unfollow" : "Follow";
    alert("Error: " + (error.response?.data?.message || error.message));
  }
}

// -------------------------------------------------

let currentUserId = null;

async function loadPublicProfile(userId) {
  currentUserId = userId;

  try {
    const token = localStorage.getItem("token");
    const response = await axios.get(`/api/users/${userId}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });

    const user = response.data.user;
    displayPublicProfile(user);
    loadFollowStatus(userId);
    loadFollowCounts(userId);
    loadUserRecipes(userId);
    setupTabs(userId);
  } catch (error) {
    if (error.response?.status === 401) {
      logout();
    } else {
      alert(
        "Error loading profile: " +
          (error.response?.data?.message || error.message),
      );
    }
  }
}

function displayPublicProfile(user) {
  // Avatar
  const avatar = document.getElementById("profileAvatar");

  if (user.profile_picture) {
    avatar.innerHTML = `<img src="${user.profile_picture}" alt="${user.username}" class="profile-avatar-image">`;
  } else {
    avatar.innerHTML = `<span id="avatarLetter">${user.username.charAt(0).toUpperCase()}</span>`;
  }

  // Username
  document.getElementById("profileUsername").textContent = user.username;

  // Bio
  document.getElementById("profileFullName").textContent =
    `${user.first_name || ""} ${user.last_name || ""}`.trim() || "No name set";
  document.getElementById("profileBio").textContent =
    user.bio || "No bio added.";
  document.getElementById("profileDietary").textContent =
    user.dietary_preferences?.length > 0
      ? `Dietary: ${user.dietary_preferences.join(", ")}`
      : "Dietary: None specified";
}

async function loadUserRecipes(userId) {
  const grid = document.getElementById("recipeGrid");
  grid.innerHTML = '<div class="loading-grid">Loading recipes...</div>';

  try {
    const token = localStorage.getItem("token");
    const response = await axios.get(`/api/users/${userId}/recipes?limit=12`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });

    const recipes = response.data.recipes;

    document.getElementById("recipeCount").textContent = response.data.total;

    if (!recipes || recipes.length === 0) {
      grid.innerHTML = `
        <div class="empty-grid">
          <div class="empty-icon">🍳</div>
          <h4>No Recipes Yet</h4>
          <p>This user hasn't shared any recipes.</p>
        </div>
      `;
      return;
    }

    displayRecipeGrid(grid, recipes);
  } catch (error) {
    grid.innerHTML = `
      <div class="empty-grid">
        <div class="empty-icon">⚠️</div>
        <h4>Error Loading Recipes</h4>
        <p>${error.response?.data?.message || error.message}</p>
      </div>
    `;
  }
}

function displayRecipeGrid(container, recipes) {
  container.innerHTML = recipes
    .map(
      (recipe) => `
    <a href="/recipe/${recipe.id}" class="recipe-grid-item">
      ${
        recipe.image_url
          ? `<img src="${recipe.image_url}" alt="${recipe.title}">`
          : `<div class="recipe-placeholder">🍳</div>`
      }
      <div class="recipe-overlay">${recipe.title}</div>
    </a>
  `,
    )
    .join("");
}

function setupTabs() {
  const tabs = document.querySelectorAll(".tab-btn");

  tabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      // Remove active class from all tabs
      tabs.forEach((t) => t.classList.remove("active"));
      this.classList.add("active");

      const tabName = this.dataset.tab;

      switch (tabName) {
        case "recipes":
          loadUserRecipes(currentUserId);
          break;
        case "favorites":
          loadUserFavorites(currentUserId);
          break;
        case "followers":
          window.location.href = `/followers/${currentUserId}`;
          break;
        case "following":
          window.location.href = `/following/${currentUserId}`;
          break;
      }
    });
  });
}

async function loadUserFavorites(userId) {
  const grid = document.getElementById("recipeGrid");
  grid.innerHTML = '<div class="loading-grid">Loading favorites...</div>';

  try {
    const token = localStorage.getItem("token");
    const response = await axios.get(`/api/users/${userId}/favorites`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });

    const favorites = response.data.favorites;

    if (!favorites || favorites.length === 0) {
      grid.innerHTML = `
        <div class="empty-grid">
          <div class="empty-icon">❤️</div>
          <h4>No Favorites Yet</h4>
          <p>This user hasn't favorited any recipes.</p>
        </div>
      `;
      return;
    }

    displayRecipeGrid(grid, favorites);
  } catch (error) {
    grid.innerHTML = `
      <div class="empty-grid">
        <div class="empty-icon">⚠️</div>
        <h4>Error Loading Favorites</h4>
        <p>${error.response?.data?.message || error.message}</p>
      </div>
    `;
  }
}

async function loadFollowCounts(userId) {
  try {
    // Load followers count
    const followersResponse = await axios.get(
      `/api/follows/${userId}/followers`,
    );
    document.getElementById("followersCount").textContent =
      followersResponse.data.followers.length;

    // Load following count
    const followingResponse = await axios.get(
      `/api/follows/${userId}/following`,
    );
    document.getElementById("followingCount").textContent =
      followingResponse.data.following.length;

    // Load recipe count
    const recipeResponse = await axios.get(
      `/api/users/${userId}/recipes?limit=1`,
    );
    document.getElementById("recipeCount").textContent =
      recipeResponse.data.total || 0;
  } catch (error) {
    console.error("Error loading counts:", error);
  }
}

async function loadFollowStatus(userId) {
  try {
    const token = localStorage.getItem("token");

    const response = await axios.get(`/api/follows/check/${userId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const isFollowing = response.data.isFollowing;

    const container = document.getElementById("followButtonContainer");

    const currentUser = JSON.parse(localStorage.getItem("user") || "{}");

    if (currentUser.id === userId) {
      container.innerHTML = `<span class="you-label">This is you</span>`;
      return;
    }

    container.innerHTML = `
      <button
        id="followProfileBtn"
        class="btn-follow ${isFollowing ? "following" : ""}"
      >
        ${isFollowing ? "Unfollow" : "Follow"}
      </button>
    `;

    document
      .getElementById("followProfileBtn")
      .addEventListener("click", () => toggleFollow(userId, isFollowing));
  } catch (err) {
    console.error(err);
  }
}

// ----------------------------------------

function showNotification(message) {
  const notification = document.createElement("div");
  notification.className = "notification";
  notification.textContent = message;
  notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background: #38a169;
        color: white;
        border-radius: 5px;
        font-weight: 500;
        z-index: 1000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    `;
  document.body.appendChild(notification);
  setTimeout(() => {
    notification.style.opacity = "0";
    notification.style.transition = "opacity 0.3s";
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "/login";
}
